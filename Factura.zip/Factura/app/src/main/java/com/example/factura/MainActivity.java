package com.example.factura;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    private EditText Cantidad1EditText, Cantidad2EditText, Cantidad3EditText, Cantidad4EditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    Cantidad1EditText = findViewById(R.id.Agregar1);
    Cantidad2EditText = findViewById(R.id.Agregar2);
    Cantidad3EditText = findViewById(R.id.Agregar3);
    Cantidad4EditText = findViewById(R.id.Agregar4);




        private void openResultActivity(String Busores) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("Busores", Busores);
            startActivity(intent);
        }

        private void openResultActivity(String TenisRes) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("TenisRes", TenisRes);
            startActivity(intent);
        }
        private void openResultActivity(String CadenaRes) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("CadenaRes", CadenaRes);
            startActivity(intent);
        }
        private void openResultActivity(String CamisetaRes) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("CamisetaRes", CamisetaRes);
            startActivity(intent);
        }
        private void openResultActivity(String SubTotal) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("SubTotal", SubTotal);
            startActivity(intent);
        }
        private void openResultActivity(String Iva) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("Iva", Iva);
            startActivity(intent);
        }
        private void openResultActivity(String Total) {
            Intent intent = new Intent(this, fact.class);
            intent.putExtra("Total", Total);
            startActivity(intent);
        }











    }
}